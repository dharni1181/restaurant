import React from 'react';

const Menu = () => {
  return <h2>menu component</h2>;
};

export default Menu;
