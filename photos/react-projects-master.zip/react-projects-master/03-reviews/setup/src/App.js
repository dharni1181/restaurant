import React from 'react';
import Review from './Review';
function App() {
  return <h2>reviews project setup</h2>;
}

export default App;
