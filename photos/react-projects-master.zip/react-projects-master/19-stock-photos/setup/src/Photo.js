import React from 'react'

const Photo = () => {
  return <h2>photo component</h2>
}

export default Photo
