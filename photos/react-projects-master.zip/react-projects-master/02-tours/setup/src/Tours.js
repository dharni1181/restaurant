import React from 'react';
import Tour from './Tour';
const Tours = () => {
  return <h2>tours component</h2>;
};

export default Tours;
