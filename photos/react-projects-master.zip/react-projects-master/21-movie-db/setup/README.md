```sh
npm install react-router-dom@6
```
